const clock = document.querySelector("#clock");

clock.innerText = "lalalalalaa"

function sayHello() {
    console.log("Hello");
} 

setInterval(sayHello, 5000);